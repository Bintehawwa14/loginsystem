<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="/Sports club">Sports club</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-5">
        <li class="nav-item">
          <a class="nav-link " aria-current="page" href="/Sports club" style="font-size: 20px; font-weight: bold;">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/sports club/index.php" style="font-size: 20px; font-weight: bold;">players</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/sports club/index.php" style="font-size: 20px; font-weight: bold;">Sports</a>
          
          
          <li class="nav-item">
          <a class="nav-link" href="sports club" style="font-size: 20px; font-weight: bold;">About us</a>
        </li>
          
        </li>
        </li>
        
    <
            <!-- Right-most Login & Signup buttons -->
            <div class="mx-5">
    <div class="d-flex"> <!-- Pushes buttons to the far right -->
        <a class="btn btn-danger px-3 " href="registration.php">REGISTER</a>
    </div>
    </ul>
</div>
        
          </a>
      </ul>
    </div>
</div>
  
</nav> 
<style>
  .navbar-nav .nav-link {
    font-size: 18px;
    font-weight: 500;
    transition: color 0.3s ease-in-out;
  }
  .navbar-nav .nav-link:hover {
    color: #f8d210 !important;
  }
  .dropdown-menu {
    background-color: #343a40;
  }
  .dropdown-menu .dropdown-item:hover {
    background-color: #495057;body {
    padding-top: 70px; /* Ensures navbar does not overlap with content */
}

.navbar {
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000; /* Ensure it stays on top */
}
body {
    padding-top: 70px; /* Prevents navbar from overlapping content */
}

  }
</style>
