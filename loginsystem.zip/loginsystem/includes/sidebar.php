  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="welcome.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            
                 
                            <a class="nav-link" href="profile.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Profile
                            </a>

                            <?php 
 // Ensure session is started

// Check kis tarah ka user logged in hai
if (isset($_SESSION['adminid'])) { 
    $changePasswordLink = "../admin/change-password.php"; // Admin ke liye correct path
} elseif (isset($_SESSION['userid'])) { 
    $changePasswordLink = "change-password.php"; // User ke liye correct path
} else {
    $changePasswordLink = "../index.php"; // Agar koi logged in nahi hai, to index pe bhejo
}
?>

<a class="nav-link" href="<?php echo $changePasswordLink; ?>">
    <div class="sb-nav-link-icon"><i class="fas fa-key"></i></div>
    Change Password
</a>


                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Signout
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>