<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sports club</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <style>
        .carousel-caption {
            color: white; /* Default text color */
            background: rgba(0, 0, 0, 0.5); /* Dark background for readability */
            padding: 10px;
            border-radius: 5px;
        }

        .carousel-caption h3 {
            color: red; /* Heading color */
            font-weight: bold;
        }

        .carousel-caption p {
            color: yellow; /* Paragraph text color */
            font-size: 18px;
        }
    </style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Slider with Fixed Text</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        .slider-container {
            position: relative;
            width: 100%;
            max-width: 800px;
            height: 400px;
            overflow: hidden;
            margin: auto;
        }
        .slides {
            display: flex;
            width: 300%; /* Adjust based on the number of images */
            animation: slide 6s infinite linear;
        }
        .slides img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
        @keyframes slide {
            0%, 100% { transform: translateX(0); }
            33% { transform: translateX(-100%); }
            66% { transform: translateX(-200%); }
        }
        .text-overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 24px;
            font-weight: bold;
            background: rgba(0, 0, 0, 0.5);
            padding: 10px 20px;
            border-radius: 5px;
        }
    </style>

</head>
<body style="background-color: <?php echo 'lightblue'; ?>;">
<?php require 'sports club/partials/_nav.php' ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>   
<div class="container">

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="sports club/images/basketball.jpg" alt="basketball" style="width:100%; height: 500px;">
        <div class="carousel-caption">
            <h3>Basketball Tournament</h3>
            <p>Join the thrilling basketball matches!</p>
        </div>
      </div>

      <div class="item">
        <img src="sports club/images/batmintan.jpg" alt="batmintan" style="width:100%; height: 500px;">
        <div class="carousel-caption">
            <h3>Badminton Championship</h3>
            <p>Be a part of the exciting badminton events!</p>
        </div>

      </div>
    
      <div class="item">
        <img src="sports club/images/cricket.jpg" alt="cricket" style="width:100%; height: 500px;">
        <div class="carousel-caption">
            <h3>Cricket League</h3>
            <p>Experience the best of women's cricket!</p>
        </div>
      </div>
        <div class="text-overlay" style="
    color: yellow; /* Change text color */
    font-size: 36px; /* Increase text size */
    font-weight: bold;
    background: rgba(0, 0, 0, 0.7); /* Darker background */
    padding: 15px 30px; /* Increase padding */
    border-radius: 10px;
    text-shadow: 2px 2px 5px black; /* Add shadow for contrast */
">
    <?php echo "WELCOME TO FG KHARIAN WOMEN SPORTS CLUB "; ?>
</div>
        
        </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
      </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>



</body>
<div style="
    width: 100%;
    max-width: 1100px; /* Same width as slider */
    margin: 30px auto;
    padding: 20px;
    text-align: center;
    color: #333;
    background: #f8f9fa;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
">
    <h2 style="color: #007BFF;">About Us</h2>
    <p style="font-size: 18px; line-height: 1.6;">
        Welcome to our sports club! We provide women with a platform to engage in various sports activities, 
        participate in tournaments, and build a strong community. Our mission is to empower women through sports and fitness.
    </p>

    <!-- Images in About Us -->
    <div style="
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 20px;
    ">
        <img src="sports club/images/basketball.jpg" alt="basketball" style="width: 30%; border-radius: 10px;">
        <img src="sports club/images/batmintan.jpg" alt="Batmintan" style="width: 30%; border-radius: 10px;">
        <img src="sports club/images/cricket.jpg" alt="Cricket" style="width: 30%; border-radius: 10px;">
    </div>
</div>
</div>
<!-- Footer Section -->
<div style="
    width: 100%;
    background:  #222;
    color: white;
    text-align: center;
    padding: 15px 0;
    margin-top: 30px;
    font-size: 18px;
">
    <p>&copy; <?php echo date('Y'); ?> Kharian Sports Club for Women. All Rights Reserved.</p>
    <p>Developed by:</p>
    <p>
        Amrana Bibi (Roll No: 058886) | Areeba Farooq (Roll No: 058881) | Areej Fatima (Roll No: 058897)
    </p>
</div>

</html>