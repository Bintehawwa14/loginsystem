<?php
include("db_connection.php"); // Your DB connection file
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['approve'])) {
    $user_id = $_GET['approve'];
    $update_query = "UPDATE users SET status = 1 WHERE id = $user_id";
    mysqli_query($conn, $update_query);
    header("Location: admin_approval.php"); // Refresh the page
}

// Fetch pending users
$result = mysqli_query($conn, "SELECT * FROM users WHERE status = 0");
?>

<h2>Pending User Approvals</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Action</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><a href="?approve=<?php echo $row['id']; ?>">Approve</a></td>
        </tr>
    <?php } ?>
</table>
